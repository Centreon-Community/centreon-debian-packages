ALTER TABLE `centreon_acl` ADD INDEX ( `host_id` , `service_id` , `group_id` );
 