$mysql_host = "@@db_cstg_server@@";
$mysql_user = "@@db_cstg_user@@";
$mysql_passwd = "@@db_cstg_pass@@";
$mysql_database_oreon = "@@db_centreon@@";
$mysql_database_ods = "@@db_cstg@@";
1;

