
-- Grant Centreon2 user on Centreon2ctsg database
GRANT SELECT, UPDATE, INSERT, DELETE ON `@@db_ctsg@@` . * TO '@@db_cstg_user@@'@'@@db_cstg_server@@';

