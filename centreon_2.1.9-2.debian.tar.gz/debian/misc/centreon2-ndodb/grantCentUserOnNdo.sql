
-- Grant Centreon2 user on Centreon2ndo database
-- GRANT SELECT, UPDATE, INSERT, DELETE ON `@@db_ndo@@` . * TO '@@db_user@@'@'@@db_server@@';

